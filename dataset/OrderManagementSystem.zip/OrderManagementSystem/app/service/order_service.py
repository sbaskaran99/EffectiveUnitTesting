# app/service/order_service.py

from app.model.order import Order
from app.repository.order_repository import OrderRepository

class OrderService:
    def __init__(self, order_repository: OrderRepository):
        self.order_repository = order_repository

    def create_order(self, item: str, quantity: int) -> Order:
        if quantity <= 0:
            raise ValueError("Quantity must be greater than zero")
        order = Order(item, quantity)
        self.order_repository.save(order)
        return order

    def get_order_by_id(self, order_id: int) -> Order:
        return self.order_repository.find_by_id(order_id)

    def get_all_orders(self) -> list[Order]:
        return self.order_repository.find_all()
