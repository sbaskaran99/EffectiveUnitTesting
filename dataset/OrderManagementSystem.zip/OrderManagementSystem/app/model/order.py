# app/model/order.py

class Order:
    counter = 1

    def __init__(self, item, quantity):
        self.id = Order.counter
        Order.counter += 1
        self.item = item
        self.quantity = quantity

    def __str__(self):
        return f"Order(id={self.id}, item='{self.item}', quantity={self.quantity})"
