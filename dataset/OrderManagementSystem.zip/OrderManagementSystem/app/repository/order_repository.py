# app/repository/order_repository.py

from abc import ABC, abstractmethod
from app.model.order import Order

class OrderRepository(ABC):
    
    @abstractmethod
    def save(self, order: Order):
        pass

    @abstractmethod
    def find_by_id(self, order_id: int) -> Order:
        pass

    @abstractmethod
    def find_all(self) -> list[Order]:
        pass
