# app/repository/in_memory_order_repository.py

from app.model.order import Order
from app.repository.order_repository import OrderRepository

class InMemoryOrderRepository(OrderRepository):
    def __init__(self):
        self.orders = []

    def save(self, order: Order):
        self.orders.append(order)

    def find_by_id(self, order_id: int) -> Order:
        for order in self.orders:
            if order.id == order_id:
                return order
        return None

    def find_all(self) -> list[Order]:
        return self.orders
